/*
SQLyog Job Agent v11.11 (32 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.5-10.1.21-MariaDB : Database - pijat
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`pijat` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `pijat`;

/*Table structure for table `banks` */

DROP TABLE IF EXISTS `banks`;

CREATE TABLE `banks` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(100) NOT NULL,
  `bank_account_number` varchar(100) NOT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `banks` */

insert  into `banks` values (1,'Mandiri',''),(2,'BCA',''),(3,'BRI','');

/*Table structure for table `branches` */

DROP TABLE IF EXISTS `branches`;

CREATE TABLE `branches` (
  `branch_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(200) NOT NULL,
  `branch_img` text NOT NULL,
  `branch_desc` text NOT NULL,
  `branch_address` text NOT NULL,
  `branch_phone` varchar(100) NOT NULL,
  `branch_city` varchar(100) NOT NULL,
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `branches` */

insert  into `branches` values (3,'Bakmi Gili 1','1487748757_logo.png','','Delta Mall','0315926983','Surabaya'),(4,'Bakmi Gili 2','1487748767_logo.png','Cabang Baru Balkpapan','Tunjungan Plaza','08123120398','Surabaya');

/*Table structure for table `buildings` */

DROP TABLE IF EXISTS `buildings`;

CREATE TABLE `buildings` (
  `building_id` int(11) NOT NULL AUTO_INCREMENT,
  `building_name` varchar(100) NOT NULL,
  `building_img` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`building_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `buildings` */

insert  into `buildings` values (7,'Utama Delta','1487748710_room.png',3),(8,'Utama TP ','1487748733_room.png',4),(9,'Utama','',5);

/*Table structure for table `employees` */

DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `employee_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `employees` */

/*Table structure for table `item_stocks` */

DROP TABLE IF EXISTS `item_stocks`;

CREATE TABLE `item_stocks` (
  `item_stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `item_stock_qty` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`item_stock_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `item_stocks` */

insert  into `item_stocks` values (21,28,12,3),(22,29,10,3);

/*Table structure for table `items` */

DROP TABLE IF EXISTS `items`;

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `item_limit` int(11) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

/*Data for the table `items` */

insert  into `items` values (28,'Timun',1,10),(29,'Udang',1,20);

/*Table structure for table `journal_types` */

DROP TABLE IF EXISTS `journal_types`;

CREATE TABLE `journal_types` (
  `journal_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `journal_type_name` varchar(200) NOT NULL,
  PRIMARY KEY (`journal_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `journal_types` */

insert  into `journal_types` values (1,'Penjualan'),(2,'Pembelian'),(3,'Pemasukan lainnya'),(4,'Pengeluaran lainnya');

/*Table structure for table `journals` */

DROP TABLE IF EXISTS `journals`;

CREATE TABLE `journals` (
  `journal_id` int(11) NOT NULL AUTO_INCREMENT,
  `journal_type_id` int(11) NOT NULL,
  `data_id` int(11) NOT NULL,
  `data_url` text NOT NULL,
  `journal_debit` int(11) NOT NULL,
  `journal_credit` int(11) NOT NULL,
  `journal_piutang` int(11) NOT NULL,
  `journal_hutang` int(11) NOT NULL,
  `journal_date` date NOT NULL,
  `journal_desc` text NOT NULL,
  `bank_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`journal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `journals` */

insert  into `journals` values (1,1,2,'',24000,0,0,0,'2017-02-28','Meja Meja 4',0,11,3),(2,1,0,'',53000,0,0,0,'2017-03-01','Meja Meja 2',0,11,3),(3,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 2',0,11,3),(4,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(5,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(6,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(7,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(8,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(9,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(10,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(11,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(12,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(13,1,0,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(14,1,15,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(15,1,16,'',55000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3),(16,1,17,'',110000,0,0,0,'2017-03-01','Meja Meja 4',0,11,3);

/*Table structure for table `kategori_utama` */

DROP TABLE IF EXISTS `kategori_utama`;

CREATE TABLE `kategori_utama` (
  `id_kategori_utama` int(11) NOT NULL AUTO_INCREMENT,
  `kategori_utama_name` varbinary(30) NOT NULL,
  PRIMARY KEY (`id_kategori_utama`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `kategori_utama` */

insert  into `kategori_utama` values (1,'Bakmie'),(2,'Nasi'),(3,'Kwetiauw'),(4,'Minuman'),(5,'Paket'),(11,'Go Food');

/*Table structure for table `member_items` */

DROP TABLE IF EXISTS `member_items`;

CREATE TABLE `member_items` (
  `member_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`member_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `member_items` */

/*Table structure for table `members` */

DROP TABLE IF EXISTS `members`;

CREATE TABLE `members` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_name` varchar(100) NOT NULL,
  `member_phone` varchar(100) NOT NULL,
  `member_alamat` varchar(30) NOT NULL,
  `member_email` varchar(200) NOT NULL,
  `member_settlement` int(11) NOT NULL,
  `member_discount` int(11) NOT NULL,
  `member_discount_type` int(11) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=latin1;

/*Data for the table `members` */

insert  into `members` values (250,'Tirta Rachmandiri','085821364004','Simo Sidomulyo 5 No. 46 B','racodex@gmail.com',0,2,0);

/*Table structure for table `menu_recipes` */

DROP TABLE IF EXISTS `menu_recipes`;

CREATE TABLE `menu_recipes` (
  `menu_recipe_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` int(11) NOT NULL,
  PRIMARY KEY (`menu_recipe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `menu_recipes` */

/*Table structure for table `menu_types` */

DROP TABLE IF EXISTS `menu_types`;

CREATE TABLE `menu_types` (
  `menu_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_type_name` varchar(100) NOT NULL,
  `id_kategori_utama` int(11) NOT NULL,
  PRIMARY KEY (`menu_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `menu_types` */

insert  into `menu_types` values (1,'Go Food',11),(2,'All Nasi Group',2),(3,'All Minuman Group',4),(4,'All Paket',5),(5,'All Bakmie Group',1),(6,'All Kwetiauw',3);

/*Table structure for table `menus` */

DROP TABLE IF EXISTS `menus`;

CREATE TABLE `menus` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_kategori` int(11) NOT NULL,
  `menu_type_id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `menu_original_price` int(11) NOT NULL,
  `menu_margin_price` int(11) NOT NULL,
  `menu_price` int(11) NOT NULL,
  `menu_img` text NOT NULL,
  `partner_id` int(11) NOT NULL,
  `out_time` varchar(10) NOT NULL,
  `dapur_id` int(11) NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=latin1;

/*Data for the table `menus` */

insert  into `menus` values (0,5,4,'P. Fiesta Mie Goreng',25000,0,25000,'',1,'30',1),(1,1,1,'Mie Ayam',21000,0,21000,'1488257805_mie-ayam-jamur.jpg',1,'30',1),(2,1,1,'Mie Pangsit',24000,0,24000,'mie-pangsit.jpg',1,'30',1),(3,1,1,'Bihun Pangsit',24000,0,24000,'',1,'30',1),(4,1,1,'Mie Bakwan',26000,0,26000,'',1,'30',1),(5,1,1,'Mie Ayam Jamur',25000,0,25000,'mie-ayam-jamur.jpg',1,'30',1),(6,1,1,'Mie Gili Spesial',28000,0,28000,'1488257857_mie-gili-special.JPG',1,'30',1),(7,1,1,'Mie Babat',25000,0,25000,'mie-babat.jpg',1,'30',1),(8,1,1,'Mie Goreng Ayam',26000,0,26000,'1488257886_mie-goreng.jpg',1,'30',1),(9,1,1,'Mie gr Seafod',30000,0,30000,'1488257898_mie-goreng-seafood.JPG',1,'30',1),(10,1,1,'Mie Cap Cay',30000,0,30000,'',1,'30',1),(11,1,1,'Bihun Goreng Ayam',25000,0,25000,'',1,'30',1),(12,1,1,'Bihun Seafood',30000,0,30000,'',1,'30',1),(13,1,1,'Bihun Capcay',30000,0,30000,'',1,'30',1),(14,1,1,'Mie Polos',18000,0,18000,'',1,'30',1),(15,1,1,'Lo Mie',26000,0,26000,'',1,'30',1),(16,1,1,'I Fu Mie',30000,0,30000,'',1,'30',1),(17,1,1,'Tamie Goreng Ayam',28000,0,28000,'1488257948_tamie-goreng.jpg',1,'30',1),(18,1,1,'Tamie Cap cay',30000,0,30000,'1488257934_tamie-capcay.JPG',1,'30',1),(19,3,6,'Kwetiauw Goreng Ayam',25000,0,25000,'',1,'30',1),(20,3,6,'Kwetiauw Seafood',30000,0,30000,'',1,'30',1),(21,3,6,'Kwetiauw Cap Cay',30000,0,30000,'',1,'30',1),(22,1,1,'HP Ayam Jamur',30000,0,30000,'',1,'30',1),(23,1,1,'HP Seafood',30000,0,30000,'',1,'30',1),(24,2,2,'Nasi Goreng Telur',18000,0,18000,'',1,'30',1),(25,2,2,'Nasi Goreng Ayam',22000,0,22000,'1488258232_nasi-ayam.JPG',1,'30',1),(26,2,2,'Nasi Goreng babat',23000,0,23000,'',1,'30',1),(27,2,2,'Nasi Goreng Udang',27000,0,27000,'1488258423_nasi-goreng-udang.jpg',1,'30',1),(28,2,2,'Nasi Goreng Kepiting',27000,0,27000,'',1,'30',1),(29,2,2,'Nasi Goreng Seafood',27000,0,27000,'1488258307_nasi-goreng-seafood.jpg',1,'30',1),(30,2,2,'Nasi Goreng Hongkong',26000,0,26000,'1488258349_nasi-goreng-hongkong.jpg',1,'30',1),(31,2,2,'Nasi Goreng Mawut',24000,0,24000,'',1,'30',1),(32,2,2,'Nasi Goreng Ikan Teri',23000,0,23000,'',1,'30',1),(33,2,2,'Nasi Goreng Ikan Asin',23000,0,23000,'1488258372_nasi-goreng-ikan-asin.jpg',1,'30',1),(34,2,2,'Nasi Udang',30000,0,30000,'1488258675_nasi-udang.jpg',1,'30',1),(35,2,2,'Nasi Ayam',30000,0,30000,'',1,'30',1),(36,2,2,'Nasi Cap Cay',30000,0,30000,'',1,'30',1),(37,2,2,'Nasi Putih',5000,0,5000,'',1,'30',1),(38,1,1,'Cap Cay Goreng',30000,0,30000,'1488253476_capcay-goreng.JPG',1,'30',1),(39,1,1,'Koloke',30000,0,30000,'1488257731_koloke.jpg',1,'30',1),(40,1,1,'Fu Yung Hai ',30000,0,30000,'1488257702_fu-yung-hai.JPG',1,'30',1),(41,1,1,'Ayam cabe kering',31000,0,31000,'1488253373_ayam-cabe-kering.JPG',1,'30',1),(42,1,1,'Ayam Saos Inggris',32000,0,32000,'1488253396_ayam-saus-inggris.jpg',1,'30',1),(43,1,1,'Ayam Lada Hitam',32000,0,32000,'',1,'30',1),(44,1,1,'Cumi Saos Inggris',32000,0,32000,'',1,'30',1),(45,1,1,'Cumi Lada Hitam',32000,0,32000,'',1,'30',1),(46,1,1,'Cumi Cabe Kering',32000,0,32000,'',1,'30',1),(47,1,1,'Sapo Tahu Seafood',32000,0,32000,'',1,'30',1),(48,1,1,'Bakwan sapi',22000,0,22000,'1488253449_bakwan-sapii.JPG',1,'30',1),(49,1,1,'Bakwan Campur',28500,0,28500,'1488253427_bakwan-campur.JPG',1,'30',1),(50,1,1,'Pangsit Goreng',18000,0,18000,'1488258621_pangsit-goreng.jpg',1,'30',1),(51,1,1,'Tahu / Siomay ',8500,0,8500,'1488258599_siomay-tahu.jpg',1,'30',1),(52,1,1,'Lumpia Udang',20000,0,20000,'1488258208_lumpia-goreng.JPG',1,'30',1),(53,1,1,'Telur',5000,0,5000,'',1,'30',1),(54,4,3,'Es Teh Tawar',4000,0,4000,'',1,'30',1),(55,4,3,'Es Teh Manis',5000,0,5000,'',1,'30',1),(56,4,3,'Es Cao',5000,0,5000,'',1,'30',1),(57,4,3,'Es Jeruk',8000,0,8000,'',1,'30',1),(58,4,3,'Lemon Tea',8000,0,8000,'',1,'30',1),(59,4,3,'Milo',10000,0,10000,'',1,'30',1),(60,4,3,'Es Sirup',6000,0,6000,'',1,'30',1),(61,4,3,'Teh Botol',6000,0,6000,'',1,'30',1),(62,4,3,'Fruit Tea',8000,0,8000,'',1,'30',1),(63,4,3,'Cheers Botol',6000,0,6000,'',1,'30',1),(64,4,3,'Es Telasih',8000,0,8000,'',1,'30',1),(65,4,3,'Es Lechy',11000,0,11000,'',1,'30',1),(66,4,3,'Jus apel',17000,0,17000,'1488258075_jus-apel.jpg',1,'30',1),(67,4,3,'Jus apokat',21000,0,21000,'',1,'30',1),(68,4,3,'Jus melon',17000,0,17000,'',1,'30',1),(69,4,3,'Jus jeruk',17000,0,17000,'1488258089_jus-jeruk.jpg',1,'30',1),(70,4,3,'Jus tomat',17000,0,17000,'1488258112_jus-tomat.jpg',1,'30',1),(71,4,3,'Jus sirsat',17000,0,17000,'1488258057_jus-sirsak.jpg',1,'30',1),(72,4,3,'Jus strawberry',20000,0,20000,'1488258128_jus-strawbery.jpg',1,'30',1),(73,4,3,'Jus lechy',20000,0,20000,'1488258146_jus-lechy.jpg',1,'30',1),(74,4,3,'Tebs/FruitTea Besar',9000,0,9000,'',1,'30',1),(75,1,1,'Paket Koloke',28000,0,28000,'1488257743_koloke.jpg',1,'30',1),(76,1,1,'Paket Fuyunghai',28000,0,28000,'',1,'30',1),(77,5,4,'Paket Ayam Cabe Kering',28000,0,28000,'',1,'30',1),(78,5,4,'P. Ayam Lada Hitam',28000,0,28000,'',1,'30',1),(79,5,4,'P. Cumi Lada Hitam',28000,0,28000,'',1,'30',1),(80,5,4,'P. Ayam Saos Inggris',28000,0,28000,'',1,'30',1),(81,5,4,'P. Cumi Saos Inggris',28000,0,28000,'',1,'30',1),(82,5,4,'P. Cumi Cabe Kering',28000,0,28000,'',1,'30',1),(83,5,4,'P. Nasgor  + ES Teh',24000,0,24000,'',1,'30',1),(84,5,4,'P. Mie Goreng + Es Teh',27000,0,27000,'',1,'30',1),(85,5,4,'P. Mie Pangsit + Es Teh',26000,0,26000,'',1,'30',1),(86,5,4,'P. Nasgor  + TBS',24000,0,24000,'',1,'30',1),(87,5,4,'P. Mie Goreng + TBS',27000,0,27000,'',1,'30',1),(88,5,4,'P. Mie Pangsit + TBS',26000,0,26000,'',1,'30',1),(89,5,4,'P. Nasgor  + Cheers',24000,0,24000,'',1,'30',1),(90,5,4,'P. Mie Goreng + Cheers',27000,0,27000,'',1,'30',1),(91,5,4,'P. Mie Pangsit + Cheers',26000,0,26000,'',1,'30',1),(92,5,4,'P. Nasgor Berdua',50000,0,50000,'',1,'30',1),(93,5,4,'P. Mie Ayam Berdua',50000,0,50000,'',1,'30',1),(94,5,4,'Pahe 1 + Es Teh',24000,0,24000,'',1,'30',1),(95,5,4,'Pahe 1 + TBS',24000,0,24000,'',1,'30',1),(96,5,4,'Pahe 1 + Cheers',24000,0,24000,'',1,'30',1),(97,5,4,'Pahe 2 + Es Teh',22000,0,22000,'',1,'30',1),(98,5,4,'Pahe 2 + TBS',22000,0,22000,'',1,'30',1),(99,5,4,'Pahe 2 + Cheers',22000,0,22000,'',1,'30',1),(100,5,4,'Pahe 3 + Es Teh',22000,0,22000,'',1,'30',1),(101,5,4,'Pahe 3 + TBS',22000,0,22000,'',1,'30',1),(102,5,4,'Pahe 3 + Cheers',22000,0,22000,'',1,'30',1),(103,5,4,'Pahe 4 + Es Teh',24000,0,24000,'',1,'30',1),(104,5,4,'Pahe 4 + TBS',24000,0,24000,'',1,'30',1),(105,5,4,'Pahe 4 + Cheers',24000,0,24000,'',1,'30',1),(106,5,4,'Mi Gili Spesial + Es Teh',30000,0,30000,'',1,'30',1),(107,5,4,'Mi Gili Spesial + TBS',30000,0,30000,'',1,'30',1),(108,5,4,'Mi Gili Spesial + Cheers',30000,0,30000,'',1,'30',1),(109,5,4,'P. Fiesta Kwetiauw',25000,0,25000,'',1,'30',1),(110,5,4,'P. Fiesta Nasi Goreng',25000,0,25000,'',1,'30',1),(111,5,4,'P. Fiesta Mie Pangsit',25000,0,25000,'',1,'30',1);

/*Table structure for table `note_categories` */

DROP TABLE IF EXISTS `note_categories`;

CREATE TABLE `note_categories` (
  `note_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `note_category_name` varchar(100) NOT NULL,
  PRIMARY KEY (`note_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `note_categories` */

insert  into `note_categories` values (1,'Tanpa'),(2,'Tanpa Ikan'),(3,'Extra'),(4,'Religion'),(5,'Jenis');

/*Table structure for table `notes` */

DROP TABLE IF EXISTS `notes`;

CREATE TABLE `notes` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `note_category_id` int(11) NOT NULL,
  `note_name` varchar(100) NOT NULL,
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

/*Data for the table `notes` */

insert  into `notes` values (1,1,'No Seledri'),(2,1,'No Daun Bawang'),(3,1,'No Bawang Goreng'),(4,1,'No Bawang Goreng'),(5,1,'No Lada'),(6,2,'No Udang'),(7,2,'No Casio'),(8,2,'No Sosis'),(9,2,'No Gromoan'),(10,2,'No Hiwan'),(11,3,'Pedas S'),(12,3,'Pedas M'),(13,3,'Pedas L'),(14,3,'Pedas XL'),(15,4,'Es'),(16,4,'Normal'),(17,4,'Hangat'),(18,4,'Halal'),(19,5,'Bungkus'),(20,4,'Panas'),(21,5,'Kcp Manis'),(22,5,'Cb potong'),(23,5,'SEAFOOD');

/*Table structure for table `order_time` */

DROP TABLE IF EXISTS `order_time`;

CREATE TABLE `order_time` (
  `idt` int(11) NOT NULL AUTO_INCREMENT,
  `order_time` time NOT NULL,
  `ket` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`idt`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `order_time` */

insert  into `order_time` values (5,'07:45:00','Peak Hours',1);

/*Table structure for table `partners` */

DROP TABLE IF EXISTS `partners`;

CREATE TABLE `partners` (
  `partner_id` int(11) NOT NULL AUTO_INCREMENT,
  `partner_name` varchar(100) NOT NULL,
  PRIMARY KEY (`partner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `partners` */

insert  into `partners` values (1,'Bakmi Gili');

/*Table structure for table `payment_methods` */

DROP TABLE IF EXISTS `payment_methods`;

CREATE TABLE `payment_methods` (
  `payment_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_method_name` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `payment_methods` */

insert  into `payment_methods` values (1,'Cash'),(2,'Debit'),(3,'Credit');

/*Table structure for table `payments` */

DROP TABLE IF EXISTS `payments`;

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_jumlah` int(11) NOT NULL,
  `payment_sisa` int(11) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `payments` */

/*Table structure for table `penyesuaian_stock_cabang` */

DROP TABLE IF EXISTS `penyesuaian_stock_cabang`;

CREATE TABLE `penyesuaian_stock_cabang` (
  `penyesuaian_stock_cabang_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `date_penyesuaian` datetime NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty_awal` bigint(20) NOT NULL,
  `item_qty_new` bigint(20) NOT NULL,
  PRIMARY KEY (`penyesuaian_stock_cabang_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `penyesuaian_stock_cabang` */

/*Table structure for table `permits` */

DROP TABLE IF EXISTS `permits`;

CREATE TABLE `permits` (
  `permit_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type_id` int(11) NOT NULL,
  `side_menu_id` int(11) NOT NULL,
  `permit_acces` varchar(10) NOT NULL,
  PRIMARY KEY (`permit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=812 DEFAULT CHARSET=latin1;

/*Data for the table `permits` */

insert  into `permits` values (241,4,1,'0'),(242,4,2,'c,r,u,d'),(243,4,3,'0'),(244,4,4,'0'),(245,4,5,'0'),(246,4,6,'0'),(247,4,7,''),(248,4,8,''),(249,4,9,'c,r,u,d'),(250,4,10,'c,r,u,d'),(251,4,11,''),(252,4,12,'c,r,u,d'),(253,4,13,''),(254,4,14,''),(255,4,15,'c,r,u,d'),(256,4,16,''),(257,4,17,''),(258,4,18,''),(259,4,19,''),(260,4,20,''),(261,4,21,''),(262,4,22,'c,r,u,d'),(263,4,23,''),(264,4,24,''),(699,1,1,'0'),(700,1,2,'c,r,u,d'),(701,1,3,'0'),(702,1,4,'0'),(703,1,5,'0'),(704,1,6,'0'),(705,1,7,'c,r,u,d'),(706,1,8,'c,r,u,d'),(707,1,9,'c,r,u,d'),(708,1,10,'c,r,u,d'),(709,1,11,'c,r,u,d'),(710,1,12,'c,r,u,d'),(711,1,13,'c,r,u,d'),(712,1,14,'c,r,u,d'),(713,1,15,'c,r,u,d'),(714,1,16,'c,r,u,d'),(715,1,17,'c,r,u,d'),(716,1,18,'c,r,u,d'),(717,1,19,'c,r,u,d'),(718,1,20,'c,r,u,d'),(719,1,21,'c,r,u,d'),(720,1,22,'c,r,u,d'),(721,1,23,'c,r,u,d'),(722,1,24,'c,r,u,d'),(723,1,25,'c,r,u,d'),(724,1,26,'c,r,u,d'),(725,1,27,'c,r,u,d'),(726,1,28,'c,r,u,d'),(727,1,30,'c,r,u,d'),(728,3,1,'0'),(729,3,2,'c,r,u,d'),(730,3,3,'0'),(731,3,4,'0'),(732,3,5,'0'),(733,3,6,'0'),(734,3,7,'c,r,u,d'),(735,3,8,'c,r,u,d'),(736,3,9,'c,r,u,d'),(737,3,10,'c,r,u,d'),(738,3,11,'c,r,u,d'),(739,3,12,'c,r,u,d'),(740,3,13,'c,r,u,d'),(741,3,14,'c,r,u,d'),(742,3,15,'c,r,u,d'),(743,3,16,'c,r,u,d'),(744,3,17,'c,r,u,d'),(745,3,18,'c,r,u,d'),(746,3,19,'c,r,u,d'),(747,3,20,'c,r,u,d'),(748,3,21,'c,r,u,d'),(749,3,22,'c,r,u,d'),(750,3,23,'c,r,u,d'),(751,3,24,'c,r,u,d'),(752,3,25,'c,r,u,d'),(753,3,26,'c,r,u,d'),(754,3,27,'c,r,u,d'),(755,3,28,'c,r,u,d'),(784,2,1,'0'),(785,2,2,'c,r,u,d'),(786,2,3,'0'),(787,2,4,'0'),(788,2,5,'0'),(789,2,6,'0'),(790,2,7,''),(791,2,8,'c,r,u,d'),(792,2,9,'c,r,u,d'),(793,2,10,'c,r,u,d'),(794,2,11,''),(795,2,12,'c,r,u,d'),(796,2,13,'c,r,u,d'),(797,2,14,'c,r,u,d'),(798,2,15,'c,r,u,d'),(799,2,16,'c,r,u,d'),(800,2,17,'c,r,u,d'),(801,2,18,'c,r,u,d'),(802,2,19,'c,r,u,d'),(803,2,20,'c,r,u,d'),(804,2,21,'c,r,u,d'),(805,2,22,'c,r,u,d'),(806,2,23,''),(807,2,24,''),(808,2,25,''),(809,2,26,''),(810,2,27,''),(811,2,28,'c,r,u,d');

/*Table structure for table `purchases` */

DROP TABLE IF EXISTS `purchases`;

CREATE TABLE `purchases` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_date` date NOT NULL,
  `item_id` int(11) NOT NULL,
  `purchase_qty` int(11) NOT NULL,
  `purchase_price` int(11) NOT NULL,
  `purchase_total` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`purchase_id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

/*Data for the table `purchases` */

/*Table structure for table `reserved` */

DROP TABLE IF EXISTS `reserved`;

CREATE TABLE `reserved` (
  `reserved_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `amount` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`reserved_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `reserved` */

insert  into `reserved` values (2,51,'Fitria','0315484702','Simo Sido Mulyo 5 No. 22',4,'2017-02-24 21:00:00',0);

/*Table structure for table `side_menus` */

DROP TABLE IF EXISTS `side_menus`;

CREATE TABLE `side_menus` (
  `side_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `side_menu_name` varchar(100) NOT NULL,
  `side_menu_url` varchar(100) NOT NULL,
  `side_menu_parent` int(11) NOT NULL,
  `side_menu_icon` varchar(100) NOT NULL,
  `side_menu_level` int(11) NOT NULL,
  `side_menu_type_parent` int(11) NOT NULL,
  PRIMARY KEY (`side_menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

/*Data for the table `side_menus` */

insert  into `side_menus` values (1,'Master','#',0,'fa fa-edit',1,0),(2,'Order','order.php',0,'fa fa-cutlery',1,1),(3,'Transaksi','#',0,'fa fa-shopping-cart',1,0),(4,'Accounting','#',0,'fa fa-list-alt',1,0),(5,'Laporan','#',0,'fa fa-list-alt',1,0),(6,'Setting','#',0,'fa fa-cog',1,0),(7,'Cabang','branch.php',1,'',2,1),(8,'Ruangan','building.php',1,'',2,1),(9,'Meja','master_table.php',1,'',2,1),(10,'Menu','menu.php',1,'',2,1),(11,'Partner','partner.php',1,'',2,1),(12,'Member','member.php',1,'',2,1),(13,'Supplier','supplier.php',1,'',2,1),(14,'Voucher','voucher.php',1,'',2,1),(15,'Reservasi','reserved.php',3,'',2,1),(16,'Pembelian','purchase.php',3,'',2,1),(17,'Stok','stock.php',3,'',2,1),(18,'Arus Kas','arus_kas.php',4,'',2,1),(19,'Pemasukan Dan Pengeluaran Lainnya','jurnal_umum.php',4,'',2,1),(20,'Laporan Detail','report_detail.php',5,'',2,1),(21,'Laporan Harian','report_harian.php',5,'',2,1),(22,'Meja','table.php',6,'',2,1),(23,'User','user.php',6,'',2,1),(24,'Type User','user_type.php',6,'',2,1),(25,'Penyesuaian Stock','penyesuaian_stock.php',1,'',2,1),(26,'Laporan Penyesuaian Stock','report_penyesuaian_stock.php',5,'',2,1),(27,'Kategori Menu','kategori_menu.php',1,'',2,1);

/*Table structure for table `suppliers` */

DROP TABLE IF EXISTS `suppliers`;

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(50) NOT NULL,
  `supplier_phone` int(11) NOT NULL,
  `supplier_email` varchar(100) NOT NULL,
  `supplier_addres` varchar(100) NOT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `suppliers` */

insert  into `suppliers` values (6,'Bakmi Gili Pusat',315484702,'bakmie.gili@gmail.com','MT. Haryono No. 42');

/*Table structure for table `table_items` */

DROP TABLE IF EXISTS `table_items`;

CREATE TABLE `table_items` (
  `table_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `menu_qty` int(11) NOT NULL,
  `menu_price` int(11) NOT NULL,
  `menu_total_price` int(11) NOT NULL,
  PRIMARY KEY (`table_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `table_items` */

/*Table structure for table `table_merger_status` */

DROP TABLE IF EXISTS `table_merger_status`;

CREATE TABLE `table_merger_status` (
  `tms_id` int(11) NOT NULL AUTO_INCREMENT,
  `tms_name` varchar(100) NOT NULL,
  PRIMARY KEY (`tms_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `table_merger_status` */

insert  into `table_merger_status` values (1,'parent merger'),(2,'child merger');

/*Table structure for table `table_mergers` */

DROP TABLE IF EXISTS `table_mergers`;

CREATE TABLE `table_mergers` (
  `table_merger_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_parent_id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  PRIMARY KEY (`table_merger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `table_mergers` */

/*Table structure for table `table_reservation` */

DROP TABLE IF EXISTS `table_reservation`;

CREATE TABLE `table_reservation` (
  `id_reservation` int(11) NOT NULL AUTO_INCREMENT,
  `date_expired` datetime NOT NULL,
  `name` varchar(200) NOT NULL,
  `join_table_id` varchar(200) NOT NULL,
  `amount` int(11) NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`id_reservation`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `table_reservation` */

/*Table structure for table `table_status` */

DROP TABLE IF EXISTS `table_status`;

CREATE TABLE `table_status` (
  `table_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_status_name` varchar(100) NOT NULL,
  PRIMARY KEY (`table_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `table_status` */

insert  into `table_status` values (1,'Kosong'),(2,'Order'),(3,'Reserved');

/*Table structure for table `table_test_sync` */

DROP TABLE IF EXISTS `table_test_sync`;

CREATE TABLE `table_test_sync` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_code` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `table_test_sync` */

/*Table structure for table `tables` */

DROP TABLE IF EXISTS `tables`;

CREATE TABLE `tables` (
  `table_id` int(11) NOT NULL AUTO_INCREMENT,
  `building_id` int(11) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `data_x` int(11) NOT NULL,
  `data_y` int(11) NOT NULL,
  `chair_number` int(11) NOT NULL,
  `table_status_id` int(11) NOT NULL,
  `tms_id` int(11) NOT NULL,
  PRIMARY KEY (`table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

/*Data for the table `tables` */

insert  into `tables` values (50,7,'Delivery Delta',575,417,1,1,0),(51,7,'Meja 1',746,338,4,1,0),(52,7,'Meja 2',441,326,4,1,0),(53,7,'Meja 3',590,256,4,1,0),(54,7,'Meja 4',311,242,4,1,0),(55,7,'Meja 5',454,167,4,1,0),(56,8,'Delivery TP',605,439,1,1,0),(57,8,'Meja 1',769,344,4,1,0),(58,8,'Meja 2',476,359,4,1,0),(59,8,'Meja 3',622,255,4,1,0),(60,8,'Meja 4',308,270,4,1,0),(61,8,'Meja 5',462,174,4,1,0);

/*Table structure for table `transaction_bills` */

DROP TABLE IF EXISTS `transaction_bills`;

CREATE TABLE `transaction_bills` (
  `transaction_id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `tot_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_code` int(11) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transaction_bills` */

/*Table structure for table `transaction_details` */

DROP TABLE IF EXISTS `transaction_details`;

CREATE TABLE `transaction_details` (
  `transaction_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `transaction_detail_original_price` int(11) NOT NULL,
  `transaction_detail_margin_price` int(11) NOT NULL,
  `transaction_detail_price` int(11) NOT NULL,
  `transaction_detail_price_discount` int(11) NOT NULL,
  `transaction_detail_grand_price` int(11) NOT NULL,
  `transaction_detail_qty` int(11) NOT NULL,
  `transaction_detail_total` int(11) NOT NULL,
  PRIMARY KEY (`transaction_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `transaction_details` */

insert  into `transaction_details` values (1,1,547,16000,0,16000,0,16000,1,16000),(2,2,547,16000,0,16000,0,16000,1,16000),(3,3,548,16000,0,16000,0,16000,1,16000),(4,1,547,16000,0,16000,0,16000,7,112000),(5,2,2,24000,0,24000,0,24000,1,24000),(6,0,5,25000,0,25000,0,25000,1,25000),(7,0,17,28000,0,28000,0,28000,1,28000),(8,0,0,25000,0,25000,0,25000,1,25000),(9,0,18,30000,0,30000,0,30000,1,30000),(10,16,5,25000,0,25000,0,25000,1,25000),(11,16,9,30000,0,30000,0,30000,1,30000),(12,17,5,25000,0,25000,0,25000,1,25000),(13,17,18,30000,0,30000,0,30000,1,30000),(14,17,5,25000,0,25000,0,25000,1,25000),(15,17,18,30000,0,30000,0,30000,1,30000);

/*Table structure for table `transaction_histories` */

DROP TABLE IF EXISTS `transaction_histories`;

CREATE TABLE `transaction_histories` (
  `transaction_id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `transaction_total` int(11) NOT NULL,
  `transaction_discount` int(11) NOT NULL,
  `transaction_grand_total` int(11) NOT NULL,
  `transaction_payment` int(11) NOT NULL,
  `transaction_change` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bank_account_number` varchar(100) NOT NULL,
  `transaction_code` int(11) NOT NULL,
  `user_delete` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transaction_histories` */

/*Table structure for table `transaction_new_tmp` */

DROP TABLE IF EXISTS `transaction_new_tmp`;

CREATE TABLE `transaction_new_tmp` (
  `tnt_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `tnt_price` int(11) NOT NULL,
  `tnt_discount` int(11) NOT NULL,
  `tnt_grand_price` int(11) NOT NULL,
  `tnt_qty` int(11) NOT NULL,
  `tnt_total` int(11) NOT NULL,
  PRIMARY KEY (`tnt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transaction_new_tmp` */

/*Table structure for table `transaction_order_types` */

DROP TABLE IF EXISTS `transaction_order_types`;

CREATE TABLE `transaction_order_types` (
  `tot_id` int(11) NOT NULL AUTO_INCREMENT,
  `tot_name` varchar(100) NOT NULL,
  PRIMARY KEY (`tot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `transaction_order_types` */

insert  into `transaction_order_types` values (1,'Dining'),(2,'Take away'),(3,'Delivery');

/*Table structure for table `transaction_summary` */

DROP TABLE IF EXISTS `transaction_summary`;

CREATE TABLE `transaction_summary` (
  `id_transaction_summary` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_grtotal_summary` varchar(45) NOT NULL,
  `transaction_summarycol` varchar(45) NOT NULL,
  `transaction_total` varchar(45) NOT NULL,
  PRIMARY KEY (`id_transaction_summary`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transaction_summary` */

/*Table structure for table `transaction_tmp_details` */

DROP TABLE IF EXISTS `transaction_tmp_details`;

CREATE TABLE `transaction_tmp_details` (
  `transaction_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `transaction_detail_original_price` int(11) NOT NULL,
  `transaction_detail_margin_price` int(11) NOT NULL,
  `transaction_detail_price` int(11) NOT NULL,
  `transaction_detail_price_discount` int(11) NOT NULL,
  `transaction_detail_grand_price` int(11) NOT NULL,
  `transaction_detail_qty` int(11) NOT NULL,
  `transaction_detail_total` int(11) NOT NULL,
  `transaction_detail_status` int(11) NOT NULL,
  PRIMARY KEY (`transaction_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transaction_tmp_details` */

/*Table structure for table `transactions` */

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `jml_orang` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `transaction_total` int(11) NOT NULL,
  `transaction_discount` int(11) NOT NULL,
  `disc_member` int(11) NOT NULL,
  `transaction_grand_total` int(11) NOT NULL,
  `transaction_payment` int(11) NOT NULL,
  `transaction_change` int(11) NOT NULL,
  `transaction_disc_nominal` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bank_account_number` varchar(100) NOT NULL,
  `tax` int(11) NOT NULL,
  `transaction_code` int(11) NOT NULL,
  `flag_code` int(1) DEFAULT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

/*Data for the table `transactions` */

insert  into `transactions` values (1,53,3,0,0,'2017-02-27 04:44:06',112000,0,0,112000,112000,0,0,1,0,39,'',0,1488167046,0),(2,54,3,0,0,'2017-02-28 04:18:10',24000,0,0,24000,24000,0,0,1,0,11,'',0,1488251890,0),(3,52,3,0,0,'2017-03-01 09:05:12',53000,0,0,53000,53000,0,0,1,0,11,'',0,1488355512,0),(16,54,3,0,0,'2017-03-01 09:10:45',55000,0,0,55000,55000,0,0,1,0,11,'',0,1488355845,0),(17,54,3,0,21,'2017-03-01 17:14:10',110000,0,0,110000,110000,0,0,1,0,11,'',0,1488384850,0);

/*Table structure for table `transactions_tmp` */

DROP TABLE IF EXISTS `transactions_tmp`;

CREATE TABLE `transactions_tmp` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_id` int(11) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `member_id` int(11) NOT NULL,
  `jml_orang` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `tot_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_code` int(11) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transactions_tmp` */

/*Table structure for table `units` */

DROP TABLE IF EXISTS `units`;

CREATE TABLE `units` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(20) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `units` */

insert  into `units` values (1,'Biji'),(2,'ml'),(3,'Gram'),(4,'Pack'),(5,'Kodi');

/*Table structure for table `user_types` */

DROP TABLE IF EXISTS `user_types`;

CREATE TABLE `user_types` (
  `user_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type_name` varchar(200) NOT NULL,
  PRIMARY KEY (`user_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `user_types` */

insert  into `user_types` values (1,'Administrator'),(2,'Kasir'),(3,'Owner'),(4,'Waitress');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type_id` int(11) DEFAULT NULL,
  `user_login` varchar(100) DEFAULT NULL,
  `user_password` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_code` varchar(100) DEFAULT NULL,
  `user_phone` varchar(100) DEFAULT NULL,
  `user_img` text NOT NULL,
  `user_active_status` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

/*Data for the table `users` */

insert  into `users` values (11,3,'admin','21232f297a57a5a743894a0e4a801fc3','admin','A0001','03125435432','',1,3),(32,3,'maria','fe01ce2a7fbac8fafaed7c982a04e229','maria','','1111','',1,4),(34,1,'budi','101eb6ad45137d043a8e3f8fb3990135','budi','','3232','',1,3),(39,2,'dita','fe01ce2a7fbac8fafaed7c982a04e229','Dita','','085731404513','',1,3),(40,4,'elina','fe01ce2a7fbac8fafaed7c982a04e229','Lina','','085852731314','',1,4);

/*Table structure for table `voucher_detail` */

DROP TABLE IF EXISTS `voucher_detail`;

CREATE TABLE `voucher_detail` (
  `id_voucher_detail` int(11) NOT NULL AUTO_INCREMENT,
  `no_voucher` text NOT NULL,
  `id_branch` int(11) NOT NULL,
  `voucher_date_issued` date NOT NULL,
  `voucher_exp_date` date NOT NULL,
  `voucher_use` int(11) NOT NULL,
  `status_voucher` int(1) NOT NULL,
  `voucher_type_id` int(1) NOT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  KEY `voucher_detail_type` (`voucher_type_id`),
  KEY `id_voucher` (`id_voucher_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=2233 DEFAULT CHARSET=latin1;

/*Data for the table `voucher_detail` */

insert  into `voucher_detail` values (2203,'GRPN251',0,'2017-02-24','2017-05-01',0,0,2,1),(2204,'GRPN252',0,'2017-02-24','2017-05-01',0,0,2,1),(2205,'GRPN253',0,'2017-02-24','2017-05-01',0,0,2,1),(2206,'GRPN254',0,'2017-02-24','2017-05-01',0,0,2,1),(2207,'GRPN255',0,'2017-02-24','2017-05-01',0,0,2,1),(2208,'GRPN501',0,'2017-02-24','2017-03-03',0,0,2,2),(2209,'GRPN502',0,'2017-02-24','2017-03-03',0,0,2,2),(2210,'GRPN503',0,'2017-02-24','2017-03-03',0,0,2,2),(2211,'GRPN504',0,'2017-02-24','2017-03-03',0,0,2,2),(2212,'GRPN505',0,'2017-02-24','2017-03-03',0,0,2,2),(2213,'GRPN751',0,'2017-02-24','2017-03-16',0,0,2,3),(2214,'GRPN752',0,'2017-02-24','2017-03-16',0,0,2,3),(2215,'GRPN753',0,'2017-02-24','2017-03-16',0,0,2,3),(2216,'GRPN754',0,'2017-02-24','2017-03-16',0,0,2,3),(2217,'GRPN755',0,'2017-02-24','2017-03-16',0,0,2,3),(2218,'VCR501',0,'2017-02-24','2017-03-16',0,0,1,4),(2219,'VCR502',0,'2017-02-24','2017-03-16',0,0,1,4),(2220,'VCR503',0,'2017-02-24','2017-03-16',0,0,1,4),(2221,'VCR504',0,'2017-02-24','2017-03-16',0,0,1,4),(2222,'VCR505',0,'2017-02-24','2017-03-16',0,0,1,4),(2223,'VCR751',0,'2017-02-24','2017-03-03',0,0,1,5),(2224,'VCR752',0,'2017-02-24','2017-03-03',0,0,1,5),(2225,'VCR753',0,'2017-02-24','2017-03-03',0,0,1,5),(2226,'VCR754',0,'2017-02-24','2017-03-03',0,0,1,5),(2227,'VCR755',0,'2017-02-24','2017-03-03',0,0,1,5),(2228,'VOUCHER1001',0,'2017-02-24','2017-03-03',0,0,1,6),(2229,'VOUCHER1002',0,'2017-02-24','2017-03-03',0,0,1,6),(2230,'VOUCHER1003',0,'2017-02-24','2017-03-03',0,0,1,6),(2231,'VOUCHER1004',0,'2017-02-24','2017-03-03',0,0,1,6),(2232,'VOUCHER1005',0,'2017-02-24','2017-03-03',0,0,1,6);

/*Table structure for table `voucher_types` */

DROP TABLE IF EXISTS `voucher_types`;

CREATE TABLE `voucher_types` (
  `voucher_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_type_name` varchar(100) NOT NULL,
  PRIMARY KEY (`voucher_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `voucher_types` */

insert  into `voucher_types` values (1,'Tunai'),(2,'Persentase');

/*Table structure for table `vouchers` */

DROP TABLE IF EXISTS `vouchers`;

CREATE TABLE `vouchers` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_code` varchar(100) NOT NULL,
  `voucher_type_id` int(11) NOT NULL,
  `voucher_value` int(11) NOT NULL,
  `voucher_date` date NOT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `vouchers` */

insert  into `vouchers` values (1,'GRPN25',2,25,'2017-05-01'),(2,'GRPN50',2,50,'2017-03-03'),(3,'GRPN75',2,75,'2017-03-16'),(4,'VCR50',1,50000,'2017-03-16'),(5,'VCR75',1,75000,'2017-03-03'),(6,'VOUCHER100',1,100000,'2017-03-03');

/*Table structure for table `widget_tmp` */

DROP TABLE IF EXISTS `widget_tmp`;

CREATE TABLE `widget_tmp` (
  `wt_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `wt_desc` text NOT NULL,
  `printed` int(11) NOT NULL,
  PRIMARY KEY (`wt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

/*Data for the table `widget_tmp` */

insert  into `widget_tmp` values (6,11,2,1,43,'',0),(7,11,6,1,30,'',0),(11,39,346,1,47,'',0),(23,11,548,1,51,'',0),(25,11,547,1,0,'asdasdasd',0);

/*Table structure for table `widget_tmp_details` */

DROP TABLE IF EXISTS `widget_tmp_details`;

CREATE TABLE `widget_tmp_details` (
  `wtd_id` int(11) NOT NULL AUTO_INCREMENT,
  `wt_id` int(11) NOT NULL,
  `note_id` int(11) NOT NULL,
  PRIMARY KEY (`wtd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `widget_tmp_details` */

insert  into `widget_tmp_details` values (12,23,1),(13,23,6),(14,23,11),(15,23,15),(16,23,21),(18,25,1),(19,25,8),(20,25,13),(21,25,15),(22,25,19);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
